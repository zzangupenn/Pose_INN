from setuptools import setup, find_packages

setup(
    name="FrEIA",
    version="0.2",
    description="Framework for Easily Invertible Architectures",
    url="",
    author="",
    author_email="",
    install_requires=[],
    setup_requires=[],
    packages=find_packages(),
    ext_package="",
)
