import StatusPanel from './StatusPanel';

export default StatusPanel;
