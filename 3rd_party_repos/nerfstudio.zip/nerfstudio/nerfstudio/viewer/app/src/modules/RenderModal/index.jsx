import RenderModal from './RenderModal';

export default RenderModal;
