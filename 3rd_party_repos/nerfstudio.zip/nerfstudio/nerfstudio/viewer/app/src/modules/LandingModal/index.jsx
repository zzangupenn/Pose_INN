import LandingModel from './LandingModal';

export default LandingModel;
