import CameraPanel from './CameraPanel';

export default CameraPanel;
