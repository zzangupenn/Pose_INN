import ScenePanel from './ScenePanel';

export default ScenePanel;
