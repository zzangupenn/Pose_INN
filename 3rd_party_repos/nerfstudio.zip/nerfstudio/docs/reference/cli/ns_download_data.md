# ns-download-data

```{eval-rst}
.. argparse::
    :module: scripts.downloads.download_data
    :func: get_parser_fn
    :prog: ns-download-data
    :nodefault:
```
