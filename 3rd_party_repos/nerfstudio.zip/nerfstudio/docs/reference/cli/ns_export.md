# ns-export

```{eval-rst}
.. argparse::
    :module: scripts.exporter
    :func: get_parser_fn
    :prog: ns-export
    :nodefault:
```
