# ns-render

:::{admonition} Note
:class: warning
Make sure to have [FFmpeg](https://ffmpeg.org/download.html) installed.
:::

```{eval-rst}
.. argparse::
    :module: scripts.render
    :func: get_parser_fn
    :prog: ns-render
    :nodefault:
```
