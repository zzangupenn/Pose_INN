# ns-eval

```{eval-rst}
.. argparse::
    :module: scripts.eval
    :func: get_parser_fn
    :prog: ns-eval
    :nodefault:
```
