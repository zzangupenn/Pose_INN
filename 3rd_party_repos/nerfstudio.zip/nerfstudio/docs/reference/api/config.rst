.. _configs:

Configs
============

.. automodule:: nerfstudio.configs.base_config
   :members:
   :show-inheritance:
