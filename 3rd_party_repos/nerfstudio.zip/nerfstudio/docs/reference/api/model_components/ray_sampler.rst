.. _ray_sampler:

Ray Sampler
===================

.. automodule:: nerfstudio.model_components.ray_samplers
   :members:
   :show-inheritance: