.. _graph_modules:

Model components
===================

.. toctree::

   ray_sampler
   losses
   renderers