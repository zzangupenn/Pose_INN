.. _renderers:

Renderers
============

.. automodule:: nerfstudio.model_components.renderers
   :members:
   :show-inheritance:
