.. _colormaps:

Colormaps
----------------

.. automodule:: nerfstudio.utils.colormaps
   :members:
   :show-inheritance:
