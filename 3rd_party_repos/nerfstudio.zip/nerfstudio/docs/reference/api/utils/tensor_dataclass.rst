.. _tensor_dataclass:

TensorDataclass
=================

.. automodule:: nerfstudio.utils.tensor_dataclass
   :members:
   :show-inheritance:
