.. _math:

Math
============

.. automodule:: nerfstudio.utils.math
   :members:
   :show-inheritance:
