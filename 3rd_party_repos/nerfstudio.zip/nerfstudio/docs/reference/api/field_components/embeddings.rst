.. _embeddings:

Embeddings
===================

.. automodule:: nerfstudio.field_components.embedding
   :members:
   :show-inheritance: