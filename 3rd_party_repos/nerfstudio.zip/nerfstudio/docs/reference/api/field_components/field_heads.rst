.. _field_heads:

Field Heads
===================

.. automodule:: nerfstudio.field_components.field_heads
   :members:
   :show-inheritance: