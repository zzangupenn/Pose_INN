.. _field_modules:

Field Modules
===================

TODO: High level description of field modules and how they connect together.

.. toctree::

   encodings
   embeddings
   field_heads
   mlp
   spatial_distortions