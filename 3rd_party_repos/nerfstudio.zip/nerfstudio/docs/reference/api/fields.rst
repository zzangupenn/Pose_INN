.. _fields:

Fields
============

Base
----------------

.. automodule:: nerfstudio.fields.base_field
   :members:
   :show-inheritance:

Instant NGP
----------------

.. automodule:: nerfstudio.fields.instant_ngp_field
   :members:
   :show-inheritance:

Vanilla NeRF
----------------

.. automodule:: nerfstudio.fields.vanilla_nerf_field
   :members:
   :show-inheritance:
