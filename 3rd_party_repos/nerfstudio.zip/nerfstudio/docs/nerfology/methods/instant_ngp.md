# Instant-NGP

<h4>Instant Neural Graphics Primitives with a Multiresolution Hash Encoding</h4>

```{button-link} https://nvlabs.github.io/instant-ngp/
:color: primary
:outline:
Paper Website
```

### Running Model

```bash
ns-train instant-ngp
```


```{admonition} Coming Soon
This guide is coming soon.
```