# Copyright 2020-present NAVER Corp. Under BSD 3-clause license

import sys
import os.path as path

# workaround for sibling import
sys.path.insert(0, path.abspath(path.join(path.dirname(__file__), '..')))
