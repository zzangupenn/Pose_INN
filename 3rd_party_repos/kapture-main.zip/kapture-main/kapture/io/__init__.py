# Copyright 2020-present NAVER Corp. Under BSD 3-clause license

"""
All functions to read and write on disk the kapture objects.
"""
