# Copyright 2020-present NAVER Corp. Under BSD 3-clause license

"""
Virtual gallery to kapture import and export
"""
# TODO: import path_to_kapture if needed
