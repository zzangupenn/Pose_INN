# Copyright 2020-present NAVER Corp. Under BSD 3-clause license

"""
kapture import NMEA.
"""
