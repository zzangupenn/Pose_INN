# Copyright 2020-present NAVER Corp. Under BSD 3-clause license

from .compare import equal_kapture  # noqa: F401
